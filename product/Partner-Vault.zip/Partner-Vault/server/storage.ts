import { 
  type User, 
  type InsertUser,
  type Partner,
  type InsertPartner,
  type MetadataField,
  type InsertMetadataField,
  type DesignPattern,
  type InsertDesignPattern,
  users,
  partners,
  metadataFields,
  designPatterns
} from "@shared/schema";
import { db } from "./db";
import { eq, or, ilike, and, sql } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Partner methods
  getPartners(): Promise<Partner[]>;
  getPartner(id: number): Promise<Partner | undefined>;
  createPartner(partner: InsertPartner): Promise<Partner>;
  updatePartner(id: number, partner: Partial<InsertPartner>): Promise<Partner | undefined>;
  deletePartner(id: number): Promise<boolean>;
  searchPartners(query: string, filters?: PartnerFilters): Promise<Partner[]>;

  // Metadata Field methods
  getMetadataFields(): Promise<MetadataField[]>;
  getMetadataField(id: number): Promise<MetadataField | undefined>;
  createMetadataField(field: InsertMetadataField): Promise<MetadataField>;
  updateMetadataField(id: number, field: Partial<InsertMetadataField>): Promise<MetadataField | undefined>;
  deleteMetadataField(id: number): Promise<boolean>;
  searchMetadataFields(query: string): Promise<MetadataField[]>;

  // Design Pattern methods
  getDesignPatterns(): Promise<DesignPattern[]>;
  getDesignPattern(id: number): Promise<DesignPattern | undefined>;
  createDesignPattern(pattern: InsertDesignPattern): Promise<DesignPattern>;
  updateDesignPattern(id: number, pattern: Partial<InsertDesignPattern>): Promise<DesignPattern | undefined>;
  deleteDesignPattern(id: number): Promise<boolean>;
  searchDesignPatterns(query: string, filters?: PatternFilters): Promise<DesignPattern[]>;

  // Global search
  globalSearch(query: string): Promise<SearchResults>;
}

export interface PartnerFilters {
  platform?: string;
  phase?: string;
  region?: string;
  tier?: string;
  status?: string;
}

export interface PatternFilters {
  platform?: string;
  phase?: string;
  sport?: string;
  heuristic?: string;
  severity?: string;
  outcome?: string;
}

export interface SearchResults {
  partners: Partner[];
  metadataFields: MetadataField[];
  designPatterns: DesignPattern[];
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  // Partner methods
  async getPartners(): Promise<Partner[]> {
    return db.select().from(partners).orderBy(sql`${partners.createdAt} DESC`);
  }

  async getPartner(id: number): Promise<Partner | undefined> {
    const [partner] = await db.select().from(partners).where(eq(partners.id, id));
    return partner || undefined;
  }

  async createPartner(partner: InsertPartner): Promise<Partner> {
    const [newPartner] = await db
      .insert(partners)
      .values({ ...partner, updatedAt: new Date() })
      .returning();
    return newPartner;
  }

  async updatePartner(id: number, partner: Partial<InsertPartner>): Promise<Partner | undefined> {
    const [updated] = await db
      .update(partners)
      .set({ ...partner, updatedAt: new Date() })
      .where(eq(partners.id, id))
      .returning();
    return updated || undefined;
  }

  async deletePartner(id: number): Promise<boolean> {
    const result = await db.delete(partners).where(eq(partners.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  async searchPartners(query: string, filters?: PartnerFilters): Promise<Partner[]> {
    const conditions = [];
    
    if (query) {
      conditions.push(
        or(
          ilike(partners.name, `%${query}%`),
          ilike(partners.email, `%${query}%`),
          ilike(partners.primaryContact, `%${query}%`),
          ilike(partners.region, `%${query}%`)
        )
      );
    }

    if (filters?.platform) {
      conditions.push(eq(partners.platform, filters.platform));
    }
    if (filters?.phase) {
      conditions.push(eq(partners.phase, filters.phase));
    }
    if (filters?.region) {
      conditions.push(eq(partners.region, filters.region));
    }
    if (filters?.tier) {
      conditions.push(eq(partners.tier, filters.tier));
    }
    if (filters?.status) {
      conditions.push(eq(partners.status, filters.status));
    }

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;
    
    return db.select().from(partners).where(whereClause);
  }

  // Metadata Field methods
  async getMetadataFields(): Promise<MetadataField[]> {
    return db.select().from(metadataFields).orderBy(sql`${metadataFields.createdAt} DESC`);
  }

  async getMetadataField(id: number): Promise<MetadataField | undefined> {
    const [field] = await db.select().from(metadataFields).where(eq(metadataFields.id, id));
    return field || undefined;
  }

  async createMetadataField(field: InsertMetadataField): Promise<MetadataField> {
    const [newField] = await db
      .insert(metadataFields)
      .values({ ...field, updatedAt: new Date() })
      .returning();
    return newField;
  }

  async updateMetadataField(id: number, field: Partial<InsertMetadataField>): Promise<MetadataField | undefined> {
    const [updated] = await db
      .update(metadataFields)
      .set({ ...field, updatedAt: new Date() })
      .where(eq(metadataFields.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteMetadataField(id: number): Promise<boolean> {
    const result = await db.delete(metadataFields).where(eq(metadataFields.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  async searchMetadataFields(query: string): Promise<MetadataField[]> {
    if (!query) return this.getMetadataFields();
    
    return db.select().from(metadataFields).where(
      or(
        ilike(metadataFields.source, `%${query}%`),
        ilike(metadataFields.fieldName, `%${query}%`),
        ilike(metadataFields.reliability, `%${query}%`)
      )
    );
  }

  // Design Pattern methods
  async getDesignPatterns(): Promise<DesignPattern[]> {
    return db.select().from(designPatterns).orderBy(sql`${designPatterns.createdAt} DESC`);
  }

  async getDesignPattern(id: number): Promise<DesignPattern | undefined> {
    const [pattern] = await db.select().from(designPatterns).where(eq(designPatterns.id, id));
    return pattern || undefined;
  }

  async createDesignPattern(pattern: InsertDesignPattern): Promise<DesignPattern> {
    const [newPattern] = await db
      .insert(designPatterns)
      .values({ ...pattern, updatedAt: new Date() })
      .returning();
    return newPattern;
  }

  async updateDesignPattern(id: number, pattern: Partial<InsertDesignPattern>): Promise<DesignPattern | undefined> {
    const [updated] = await db
      .update(designPatterns)
      .set({ ...pattern, updatedAt: new Date() })
      .where(eq(designPatterns.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteDesignPattern(id: number): Promise<boolean> {
    const result = await db.delete(designPatterns).where(eq(designPatterns.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  async searchDesignPatterns(query: string, filters?: PatternFilters): Promise<DesignPattern[]> {
    const conditions = [];
    
    if (query) {
      conditions.push(
        or(
          ilike(designPatterns.patternName, `%${query}%`),
          ilike(designPatterns.description, `%${query}%`)
        )
      );
    }

    if (filters?.platform) {
      conditions.push(eq(designPatterns.platform, filters.platform));
    }
    if (filters?.phase) {
      conditions.push(eq(designPatterns.phase, filters.phase));
    }
    if (filters?.sport) {
      conditions.push(eq(designPatterns.sport, filters.sport));
    }
    if (filters?.heuristic) {
      conditions.push(ilike(designPatterns.heuristic, `%${filters.heuristic}%`));
    }
    if (filters?.severity) {
      conditions.push(eq(designPatterns.severity, filters.severity));
    }
    if (filters?.outcome) {
      conditions.push(eq(designPatterns.outcome, filters.outcome));
    }

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;
    
    return db.select().from(designPatterns).where(whereClause);
  }

  // Global search across all entities
  async globalSearch(query: string): Promise<SearchResults> {
    const [partnersResults, fieldsResults, patternsResults] = await Promise.all([
      this.searchPartners(query),
      this.searchMetadataFields(query),
      this.searchDesignPatterns(query)
    ]);

    return {
      partners: partnersResults,
      metadataFields: fieldsResults,
      designPatterns: patternsResults
    };
  }
}

export const storage = new DatabaseStorage();
