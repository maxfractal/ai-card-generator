import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertPartnerSchema, insertMetadataFieldSchema, insertDesignPatternSchema } from "@shared/schema";
import { z } from "zod";
import { fromError } from "zod-validation-error";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // ===== Partner Routes =====
  app.get("/api/partners", async (req, res) => {
    try {
      const partners = await storage.getPartners();
      res.json(partners);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch partners" });
    }
  });

  app.get("/api/partners/search", async (req, res) => {
    try {
      const query = (req.query.q as string) || "";
      const filters = {
        platform: req.query.platform as string | undefined,
        phase: req.query.phase as string | undefined,
        region: req.query.region as string | undefined,
        tier: req.query.tier as string | undefined,
        status: req.query.status as string | undefined,
      };
      const partners = await storage.searchPartners(query, filters);
      res.json(partners);
    } catch (error) {
      res.status(500).json({ error: "Failed to search partners" });
    }
  });

  app.get("/api/partners/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const partner = await storage.getPartner(id);
      if (!partner) {
        return res.status(404).json({ error: "Partner not found" });
      }
      res.json(partner);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch partner" });
    }
  });

  app.post("/api/partners", async (req, res) => {
    try {
      const validatedData = insertPartnerSchema.parse(req.body);
      const partner = await storage.createPartner(validatedData);
      res.status(201).json(partner);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: fromError(error).toString() });
      }
      res.status(500).json({ error: "Failed to create partner" });
    }
  });

  app.patch("/api/partners/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const partner = await storage.updatePartner(id, req.body);
      if (!partner) {
        return res.status(404).json({ error: "Partner not found" });
      }
      res.json(partner);
    } catch (error) {
      res.status(500).json({ error: "Failed to update partner" });
    }
  });

  app.delete("/api/partners/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deletePartner(id);
      if (!success) {
        return res.status(404).json({ error: "Partner not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete partner" });
    }
  });

  // ===== Metadata Field Routes =====
  app.get("/api/metadata-fields", async (req, res) => {
    try {
      const fields = await storage.getMetadataFields();
      res.json(fields);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch metadata fields" });
    }
  });

  app.get("/api/metadata-fields/search", async (req, res) => {
    try {
      const query = (req.query.q as string) || "";
      const fields = await storage.searchMetadataFields(query);
      res.json(fields);
    } catch (error) {
      res.status(500).json({ error: "Failed to search metadata fields" });
    }
  });

  app.get("/api/metadata-fields/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const field = await storage.getMetadataField(id);
      if (!field) {
        return res.status(404).json({ error: "Metadata field not found" });
      }
      res.json(field);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch metadata field" });
    }
  });

  app.post("/api/metadata-fields", async (req, res) => {
    try {
      const validatedData = insertMetadataFieldSchema.parse(req.body);
      const field = await storage.createMetadataField(validatedData);
      res.status(201).json(field);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: fromError(error).toString() });
      }
      res.status(500).json({ error: "Failed to create metadata field" });
    }
  });

  app.patch("/api/metadata-fields/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const field = await storage.updateMetadataField(id, req.body);
      if (!field) {
        return res.status(404).json({ error: "Metadata field not found" });
      }
      res.json(field);
    } catch (error) {
      res.status(500).json({ error: "Failed to update metadata field" });
    }
  });

  app.delete("/api/metadata-fields/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteMetadataField(id);
      if (!success) {
        return res.status(404).json({ error: "Metadata field not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete metadata field" });
    }
  });

  // ===== Design Pattern Routes =====
  app.get("/api/design-patterns", async (req, res) => {
    try {
      const patterns = await storage.getDesignPatterns();
      res.json(patterns);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch design patterns" });
    }
  });

  app.get("/api/design-patterns/search", async (req, res) => {
    try {
      const query = (req.query.q as string) || "";
      const filters = {
        platform: req.query.platform as string | undefined,
        phase: req.query.phase as string | undefined,
        sport: req.query.sport as string | undefined,
        heuristic: req.query.heuristic as string | undefined,
        severity: req.query.severity as string | undefined,
        outcome: req.query.outcome as string | undefined,
      };
      const patterns = await storage.searchDesignPatterns(query, filters);
      res.json(patterns);
    } catch (error) {
      res.status(500).json({ error: "Failed to search design patterns" });
    }
  });

  app.get("/api/design-patterns/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const pattern = await storage.getDesignPattern(id);
      if (!pattern) {
        return res.status(404).json({ error: "Design pattern not found" });
      }
      res.json(pattern);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch design pattern" });
    }
  });

  app.post("/api/design-patterns", async (req, res) => {
    try {
      const validatedData = insertDesignPatternSchema.parse(req.body);
      const pattern = await storage.createDesignPattern(validatedData);
      res.status(201).json(pattern);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: fromError(error).toString() });
      }
      res.status(500).json({ error: "Failed to create design pattern" });
    }
  });

  app.patch("/api/design-patterns/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const pattern = await storage.updateDesignPattern(id, req.body);
      if (!pattern) {
        return res.status(404).json({ error: "Design pattern not found" });
      }
      res.json(pattern);
    } catch (error) {
      res.status(500).json({ error: "Failed to update design pattern" });
    }
  });

  app.delete("/api/design-patterns/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteDesignPattern(id);
      if (!success) {
        return res.status(404).json({ error: "Design pattern not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete design pattern" });
    }
  });

  // ===== Global Search =====
  app.get("/api/search", async (req, res) => {
    try {
      const query = (req.query.q as string) || "";
      const results = await storage.globalSearch(query);
      res.json(results);
    } catch (error) {
      res.status(500).json({ error: "Failed to perform global search" });
    }
  });

  return httpServer;
}
