import { sql } from "drizzle-orm";
import { pgTable, text, varchar, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Keep existing users table for authentication
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Partners table
export const partners = pgTable("partners", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  region: varchar("region", { length: 100 }).notNull(),
  tier: varchar("tier", { length: 50 }).notNull(),
  status: varchar("status", { length: 50 }).notNull(),
  primaryContact: varchar("primary_contact", { length: 255 }).notNull(),
  email: varchar("email", { length: 255 }).notNull(),
  activeViewers: integer("active_viewers").notNull().default(0),
  totalStreams: integer("total_streams").notNull().default(0),
  
  // New fields from requirements
  platform: varchar("platform", { length: 100 }).notNull(),
  surfaceType: varchar("surface_type", { length: 100 }).notNull(),
  phase: varchar("phase", { length: 50 }).notNull(),
  notes: text("notes"),
  
  joinedDate: timestamp("joined_date").notNull().defaultNow(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertPartnerSchema = createInsertSchema(partners).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertPartner = z.infer<typeof insertPartnerSchema>;
export type Partner = typeof partners.$inferSelect;

// Metadata Fields table
export const metadataFields = pgTable("metadata_fields", {
  id: serial("id").primaryKey(),
  source: varchar("source", { length: 255 }).notNull(),
  fieldName: varchar("field_name", { length: 255 }).notNull(),
  reliability: varchar("reliability", { length: 50 }).notNull(),
  fallbackRule: text("fallback_rule"),
  knownFailures: text("known_failures"),
  
  medalRelevance: varchar("medal_relevance", { length: 50 }),
  durationClass: varchar("duration_class", { length: 50 }),
  rightsWindow: varchar("rights_window", { length: 255 }),
  
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertMetadataFieldSchema = createInsertSchema(metadataFields).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertMetadataField = z.infer<typeof insertMetadataFieldSchema>;
export type MetadataField = typeof metadataFields.$inferSelect;

// Design Patterns table
export const designPatterns = pgTable("design_patterns", {
  id: serial("id").primaryKey(),
  patternName: varchar("pattern_name", { length: 255 }).notNull(),
  outcome: varchar("outcome", { length: 50 }).notNull(),
  description: text("description"),
  
  platform: varchar("platform", { length: 100 }),
  phase: varchar("phase", { length: 50 }),
  sport: varchar("sport", { length: 100 }),
  heuristic: varchar("heuristic", { length: 255 }),
  severity: varchar("severity", { length: 50 }),
  
  partnerId: integer("partner_id").references(() => partners.id),
  
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertDesignPatternSchema = createInsertSchema(designPatterns).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertDesignPattern = z.infer<typeof insertDesignPatternSchema>;
export type DesignPattern = typeof designPatterns.$inferSelect;
