import { LucideIcon, Tv, Users, Globe, Award, Activity, BarChart3, Radio, CheckCircle, Clock, AlertCircle } from "lucide-react";

export interface Partner {
  id: string;
  name: string;
  region: "Americas" | "EMEA" | "APAC";
  tier: "Gold" | "Silver" | "Bronze";
  status: "Active" | "Onboarding" | "Inactive";
  primaryContact: string;
  email: string;
  activeViewers: number;
  totalStreams: number;
  joinedDate: string;
}

export interface ActivityLog {
  id: string;
  partnerId: string;
  partnerName: string;
  action: string;
  type: "info" | "success" | "warning";
  timestamp: string;
}

export const partners: Partner[] = [
  {
    id: "1",
    name: "StreamSport Brazil",
    region: "Americas",
    tier: "Gold",
    status: "Active",
    primaryContact: "Carlos Silva",
    email: "carlos@streamsport.br",
    activeViewers: 12500,
    totalStreams: 450,
    joinedDate: "2023-01-15",
  },
  {
    id: "2",
    name: "EuroCast Network",
    region: "EMEA",
    tier: "Gold",
    status: "Active",
    primaryContact: "Elena Weber",
    email: "elena@eurocast.eu",
    activeViewers: 8400,
    totalStreams: 320,
    joinedDate: "2023-02-10",
  },
  {
    id: "3",
    name: "Asia Pacific Sports",
    region: "APAC",
    tier: "Silver",
    status: "Active",
    primaryContact: "Kenji Tanaka",
    email: "kenji@aps.asia",
    activeViewers: 5600,
    totalStreams: 180,
    joinedDate: "2023-05-22",
  },
  {
    id: "4",
    name: "Nordic Stream",
    region: "EMEA",
    tier: "Silver",
    status: "Onboarding",
    primaryContact: "Lars Jensen",
    email: "lars@nordicstream.se",
    activeViewers: 0,
    totalStreams: 0,
    joinedDate: "2024-01-05",
  },
  {
    id: "5",
    name: "Oceana Live",
    region: "APAC",
    tier: "Bronze",
    status: "Inactive",
    primaryContact: "Sarah Jones",
    email: "sarah@oceanalive.au",
    activeViewers: 0,
    totalStreams: 45,
    joinedDate: "2023-11-12",
  },
  {
    id: "6",
    name: "North America Sports Hub",
    region: "Americas",
    tier: "Gold",
    status: "Active",
    primaryContact: "Mike Ross",
    email: "mike@nash.com",
    activeViewers: 18900,
    totalStreams: 600,
    joinedDate: "2022-11-30",
  },
];

export const recentActivity: ActivityLog[] = [
  {
    id: "101",
    partnerId: "1",
    partnerName: "StreamSport Brazil",
    action: "Started broadcasting 'Swimming Finals'",
    type: "success",
    timestamp: "2 mins ago",
  },
  {
    id: "102",
    partnerId: "4",
    partnerName: "Nordic Stream",
    action: "Completed technical verification",
    type: "info",
    timestamp: "15 mins ago",
  },
  {
    id: "103",
    partnerId: "2",
    partnerName: "EuroCast Network",
    action: "High latency detected in Frankfurt node",
    type: "warning",
    timestamp: "1 hour ago",
  },
  {
    id: "104",
    partnerId: "6",
    partnerName: "North America Sports Hub",
    action: " renewed Gold Tier contract",
    type: "success",
    timestamp: "3 hours ago",
  },
];
