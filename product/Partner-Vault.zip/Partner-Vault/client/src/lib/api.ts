import type { Partner, InsertPartner, MetadataField, InsertMetadataField, DesignPattern, InsertDesignPattern } from "@shared/schema";

const API_BASE = "/api";

// Partners API
export const partnersApi = {
  getAll: async (): Promise<Partner[]> => {
    const res = await fetch(`${API_BASE}/partners`);
    if (!res.ok) throw new Error("Failed to fetch partners");
    return res.json();
  },

  search: async (query: string, filters?: Record<string, string>): Promise<Partner[]> => {
    const params = new URLSearchParams({ q: query, ...filters });
    const res = await fetch(`${API_BASE}/partners/search?${params}`);
    if (!res.ok) throw new Error("Failed to search partners");
    return res.json();
  },

  getOne: async (id: number): Promise<Partner> => {
    const res = await fetch(`${API_BASE}/partners/${id}`);
    if (!res.ok) throw new Error("Failed to fetch partner");
    return res.json();
  },

  create: async (partner: InsertPartner): Promise<Partner> => {
    const res = await fetch(`${API_BASE}/partners`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(partner),
    });
    if (!res.ok) {
      const error = await res.json();
      throw new Error(error.error || "Failed to create partner");
    }
    return res.json();
  },

  update: async (id: number, partner: Partial<InsertPartner>): Promise<Partner> => {
    const res = await fetch(`${API_BASE}/partners/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(partner),
    });
    if (!res.ok) throw new Error("Failed to update partner");
    return res.json();
  },

  delete: async (id: number): Promise<void> => {
    const res = await fetch(`${API_BASE}/partners/${id}`, {
      method: "DELETE",
    });
    if (!res.ok) throw new Error("Failed to delete partner");
  },
};

// Metadata Fields API
export const metadataFieldsApi = {
  getAll: async (): Promise<MetadataField[]> => {
    const res = await fetch(`${API_BASE}/metadata-fields`);
    if (!res.ok) throw new Error("Failed to fetch metadata fields");
    return res.json();
  },

  search: async (query: string): Promise<MetadataField[]> => {
    const params = new URLSearchParams({ q: query });
    const res = await fetch(`${API_BASE}/metadata-fields/search?${params}`);
    if (!res.ok) throw new Error("Failed to search metadata fields");
    return res.json();
  },

  create: async (field: InsertMetadataField): Promise<MetadataField> => {
    const res = await fetch(`${API_BASE}/metadata-fields`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(field),
    });
    if (!res.ok) {
      const error = await res.json();
      throw new Error(error.error || "Failed to create metadata field");
    }
    return res.json();
  },

  update: async (id: number, field: Partial<InsertMetadataField>): Promise<MetadataField> => {
    const res = await fetch(`${API_BASE}/metadata-fields/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(field),
    });
    if (!res.ok) throw new Error("Failed to update metadata field");
    return res.json();
  },

  delete: async (id: number): Promise<void> => {
    const res = await fetch(`${API_BASE}/metadata-fields/${id}`, {
      method: "DELETE",
    });
    if (!res.ok) throw new Error("Failed to delete metadata field");
  },
};

// Design Patterns API
export const designPatternsApi = {
  getAll: async (): Promise<DesignPattern[]> => {
    const res = await fetch(`${API_BASE}/design-patterns`);
    if (!res.ok) throw new Error("Failed to fetch design patterns");
    return res.json();
  },

  search: async (query: string, filters?: Record<string, string>): Promise<DesignPattern[]> => {
    const params = new URLSearchParams({ q: query, ...filters });
    const res = await fetch(`${API_BASE}/design-patterns/search?${params}`);
    if (!res.ok) throw new Error("Failed to search design patterns");
    return res.json();
  },

  create: async (pattern: InsertDesignPattern): Promise<DesignPattern> => {
    const res = await fetch(`${API_BASE}/design-patterns`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(pattern),
    });
    if (!res.ok) {
      const error = await res.json();
      throw new Error(error.error || "Failed to create design pattern");
    }
    return res.json();
  },

  update: async (id: number, pattern: Partial<InsertDesignPattern>): Promise<DesignPattern> => {
    const res = await fetch(`${API_BASE}/design-patterns/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(pattern),
    });
    if (!res.ok) throw new Error("Failed to update design pattern");
    return res.json();
  },

  delete: async (id: number): Promise<void> => {
    const res = await fetch(`${API_BASE}/design-patterns/${id}`, {
      method: "DELETE",
    });
    if (!res.ok) throw new Error("Failed to delete design pattern");
  },
};

// Global Search
export const globalSearchApi = async (query: string) => {
  const params = new URLSearchParams({ q: query });
  const res = await fetch(`${API_BASE}/search?${params}`);
  if (!res.ok) throw new Error("Failed to perform global search");
  return res.json();
};
