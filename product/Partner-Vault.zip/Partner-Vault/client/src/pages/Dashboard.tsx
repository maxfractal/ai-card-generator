import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { partnersApi } from "@/lib/api";
import { 
  Users, 
  Tv, 
  Globe, 
  TrendingUp,
  Activity,
  Award,
  Loader2
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import abstractBg from "@assets/generated_images/abstract_olympic_streaming_background.png";
import { Badge } from "@/components/ui/badge";

export default function Dashboard() {
  const { data: partners = [], isLoading } = useQuery({
    queryKey: ["partners"],
    queryFn: () => partnersApi.getAll(),
  });

  const activePartners = partners.filter(p => p.status === "Active");
  const totalViewers = partners.reduce((sum, p) => sum + p.activeViewers, 0);
  const uniqueRegions = new Set(partners.map(p => p.region)).size;

  const stats = [
    {
      label: "Total Partners",
      value: partners.length.toString(),
      change: "+2 this month",
      icon: Users,
      trend: "up",
    },
    {
      label: "Active Streams",
      value: activePartners.length.toString(),
      change: "98% uptime",
      icon: Tv,
      trend: "up",
    },
    {
      label: "Global Reach",
      value: `${uniqueRegions} Region${uniqueRegions !== 1 ? 's' : ''}`,
      change: "Expansion pending",
      icon: Globe,
      trend: "neutral",
    },
    {
      label: "Total Viewers",
      value: totalViewers > 1000 ? `${(totalViewers / 1000).toFixed(1)}K` : totalViewers.toString(),
      change: "+12% vs last week",
      icon: TrendingUp,
      trend: "up",
    },
  ];

  const topPartners = [...partners]
    .sort((a, b) => b.activeViewers - a.activeViewers)
    .slice(0, 3);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="relative rounded-2xl overflow-hidden border border-white/10 shadow-2xl h-48 md:h-64 group">
        <div 
          className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105"
          style={{ backgroundImage: `url(${abstractBg})` }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background/90 via-background/60 to-transparent" />
        
        <div className="relative h-full flex flex-col justify-center px-8 md:px-12 z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-3xl md:text-4xl font-display font-bold text-white mb-2">
              Welcome back, Admin
            </h1>
            <p className="text-muted-foreground max-w-lg text-lg">
              Monitor your global streaming partners and manage destination hubs in real-time.
            </p>
          </motion.div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1, duration: 0.4 }}
          >
            <Card className="bg-card/50 border-white/5 backdrop-blur-sm hover:border-primary/20 transition-all duration-300">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <stat.icon className="w-5 h-5 text-primary" />
                  </div>
                  <span className={`text-xs font-medium px-2 py-1 rounded-full ${
                    stat.trend === "up" ? "bg-green-500/10 text-green-500" : "bg-white/5 text-muted-foreground"
                  }`}>
                    {stat.change}
                  </span>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">{stat.label}</p>
                  <h3 className="text-2xl font-bold font-display text-white">{stat.value}</h3>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-display font-bold text-white">Recent Partners</h2>
          </div>
          
          <Card className="bg-card/30 border-white/5">
            <CardContent className="p-0">
              <div className="divide-y divide-white/5">
                {partners.slice(0, 5).map((partner) => (
                  <div key={partner.id} className="p-4 flex items-start gap-4 hover:bg-white/5 transition-colors">
                    <div className="mt-1 w-2 h-2 rounded-full shrink-0 bg-green-500 shadow-[0_0_10px_rgba(34,197,94,0.5)]" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-white font-medium">
                        {partner.name}
                        <span className="text-muted-foreground font-normal"> - {partner.platform} ({partner.phase})</span>
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">{partner.region} • {partner.status}</p>
                    </div>
                  </div>
                ))}
                {partners.length === 0 && (
                  <div className="p-8 text-center text-muted-foreground">
                    No partners yet. Add your first partner to get started.
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <h2 className="text-xl font-display font-bold text-white">Top Partners</h2>
          <div className="space-y-4">
            {topPartners.map((partner, i) => (
              <Card key={partner.id} className="bg-card/30 border-white/5 hover:bg-card/50 transition-colors">
                <CardContent className="p-4 flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center font-bold text-white border border-white/10">
                    {partner.name.substring(0, 2).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-white truncate">{partner.name}</h4>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant="outline" className="text-[10px] px-1.5 py-0 h-4 border-white/10 text-muted-foreground">
                        {partner.region}
                      </Badge>
                      <span className="text-xs text-muted-foreground">{partner.activeViewers.toLocaleString()} viewers</span>
                    </div>
                  </div>
                  {i === 0 && <Award className="w-5 h-5 text-primary" />}
                </CardContent>
              </Card>
            ))}
            {topPartners.length === 0 && (
              <Card className="bg-card/30 border-white/5">
                <CardContent className="p-8 text-center text-muted-foreground text-sm">
                  No active partners with viewer data yet.
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
