import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { partnersApi } from "@/lib/api";
import type { InsertPartner } from "@shared/schema";
import { 
  Search, 
  Filter, 
  Plus, 
  MoreVertical, 
  Mail, 
  MapPin, 
  ShieldCheck,
  Loader2
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

export default function Partners() {
  const [searchTerm, setSearchTerm] = useState("");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [formData, setFormData] = useState<Partial<InsertPartner>>({
    activeViewers: 0,
    totalStreams: 0,
  });

  const queryClient = useQueryClient();

  const { data: partners = [], isLoading } = useQuery({
    queryKey: ["partners"],
    queryFn: () => partnersApi.getAll(),
  });

  const createMutation = useMutation({
    mutationFn: (data: InsertPartner) => partnersApi.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["partners"] });
      setIsAddDialogOpen(false);
      setFormData({ activeViewers: 0, totalStreams: 0 });
      toast.success("Partner created successfully");
    },
    onError: (error: Error) => {
      toast.error(error.message);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => partnersApi.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["partners"] });
      toast.success("Partner deleted successfully");
    },
    onError: () => {
      toast.error("Failed to delete partner");
    },
  });

  const filteredPartners = partners.filter(p => 
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.region.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.region || !formData.tier || 
        !formData.status || !formData.primaryContact || !formData.platform || 
        !formData.surfaceType || !formData.phase) {
      toast.error("Please fill in all required fields");
      return;
    }
    createMutation.mutate(formData as InsertPartner);
  };

  const getTierColor = (tier: string) => {
    switch(tier) {
      case "Gold": return "bg-yellow-500/20 text-yellow-500 border-yellow-500/50";
      case "Silver": return "bg-slate-300/20 text-slate-300 border-slate-300/50";
      case "Bronze": return "bg-orange-700/20 text-orange-400 border-orange-700/50";
      default: return "bg-secondary text-muted-foreground";
    }
  };

  const getStatusColor = (status: string) => {
    switch(status) {
      case "Active": return "bg-green-500/20 text-green-500 hover:bg-green-500/30";
      case "Onboarding": return "bg-blue-500/20 text-blue-500 hover:bg-blue-500/30";
      case "Inactive": return "bg-red-500/20 text-red-500 hover:bg-red-500/30";
      default: return "bg-secondary text-muted-foreground";
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-white">Partners</h1>
          <p className="text-muted-foreground mt-1">Manage your global streaming destinations.</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button 
              data-testid="button-add-partner"
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-medium shadow-[0_0_20px_rgba(250,204,21,0.2)]"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Partner
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-white/10 text-white sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add New Partner</DialogTitle>
              <DialogDescription>
                Enter the details for the new streaming partner destination.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit}>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Partner Name *</Label>
                    <Input 
                      id="name" 
                      data-testid="input-partner-name"
                      className="bg-secondary/50 border-white/10"
                      value={formData.name || ""}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email *</Label>
                    <Input 
                      id="email" 
                      type="email"
                      data-testid="input-partner-email"
                      className="bg-secondary/50 border-white/10"
                      value={formData.email || ""}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="contact">Primary Contact *</Label>
                    <Input 
                      id="contact"
                      data-testid="input-partner-contact"
                      className="bg-secondary/50 border-white/10"
                      value={formData.primaryContact || ""}
                      onChange={(e) => setFormData({ ...formData, primaryContact: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="region">Region *</Label>
                    <Select 
                      value={formData.region || ""} 
                      onValueChange={(value) => setFormData({ ...formData, region: value })}
                    >
                      <SelectTrigger data-testid="select-partner-region" className="bg-secondary/50 border-white/10">
                        <SelectValue placeholder="Select region" />
                      </SelectTrigger>
                      <SelectContent className="bg-card border-white/10">
                        <SelectItem value="Americas">Americas</SelectItem>
                        <SelectItem value="EMEA">EMEA</SelectItem>
                        <SelectItem value="APAC">APAC</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="tier">Tier *</Label>
                    <Select 
                      value={formData.tier || ""} 
                      onValueChange={(value) => setFormData({ ...formData, tier: value })}
                    >
                      <SelectTrigger data-testid="select-partner-tier" className="bg-secondary/50 border-white/10">
                        <SelectValue placeholder="Select tier" />
                      </SelectTrigger>
                      <SelectContent className="bg-card border-white/10">
                        <SelectItem value="Gold">Gold</SelectItem>
                        <SelectItem value="Silver">Silver</SelectItem>
                        <SelectItem value="Bronze">Bronze</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="status">Status *</Label>
                    <Select 
                      value={formData.status || ""} 
                      onValueChange={(value) => setFormData({ ...formData, status: value })}
                    >
                      <SelectTrigger data-testid="select-partner-status" className="bg-secondary/50 border-white/10">
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                      <SelectContent className="bg-card border-white/10">
                        <SelectItem value="Active">Active</SelectItem>
                        <SelectItem value="Onboarding">Onboarding</SelectItem>
                        <SelectItem value="Inactive">Inactive</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="platform">Platform *</Label>
                    <Select 
                      value={formData.platform || ""} 
                      onValueChange={(value) => setFormData({ ...formData, platform: value })}
                    >
                      <SelectTrigger data-testid="select-partner-platform" className="bg-secondary/50 border-white/10">
                        <SelectValue placeholder="Select platform" />
                      </SelectTrigger>
                      <SelectContent className="bg-card border-white/10">
                        <SelectItem value="iOS">iOS</SelectItem>
                        <SelectItem value="Android">Android</SelectItem>
                        <SelectItem value="Web">Web</SelectItem>
                        <SelectItem value="Roku">Roku</SelectItem>
                        <SelectItem value="YoutubeTV">YoutubeTV</SelectItem>
                        <SelectItem value="SlingTV">SlingTV</SelectItem>
                        <SelectItem value="DirectTV">DirectTV</SelectItem>
                        <SelectItem value="Peacock">Peacock</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="surface">Surface Type *</Label>
                    <Select 
                      value={formData.surfaceType || ""} 
                      onValueChange={(value) => setFormData({ ...formData, surfaceType: value })}
                    >
                      <SelectTrigger data-testid="select-partner-surface" className="bg-secondary/50 border-white/10">
                        <SelectValue placeholder="Select surface" />
                      </SelectTrigger>
                      <SelectContent className="bg-card border-white/10">
                        <SelectItem value="Hub">Hub</SelectItem>
                        <SelectItem value="Rail">Rail</SelectItem>
                        <SelectItem value="Card">Card</SelectItem>
                        <SelectItem value="Player">Player</SelectItem>
                        <SelectItem value="Search">Search</SelectItem>
                        <SelectItem value="Thumbnail">Thumbnail</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phase">Phase *</Label>
                  <Select 
                    value={formData.phase || ""} 
                    onValueChange={(value) => setFormData({ ...formData, phase: value })}
                  >
                    <SelectTrigger data-testid="select-partner-phase" className="bg-secondary/50 border-white/10">
                      <SelectValue placeholder="Select phase" />
                    </SelectTrigger>
                    <SelectContent className="bg-card border-white/10">
                      <SelectItem value="Pre-Games">Pre-Games</SelectItem>
                      <SelectItem value="Live">Live</SelectItem>
                      <SelectItem value="Post">Post</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="notes">Notes</Label>
                  <Textarea 
                    id="notes"
                    data-testid="textarea-partner-notes"
                    className="bg-secondary/50 border-white/10 min-h-[80px]"
                    value={formData.notes || ""}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button 
                  type="submit" 
                  data-testid="button-save-partner"
                  className="bg-primary text-primary-foreground"
                  disabled={createMutation.isPending}
                >
                  {createMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Creating...
                    </>
                  ) : "Create Partner"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex items-center gap-4 bg-card/30 p-4 rounded-lg border border-white/5 backdrop-blur-sm">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input 
            placeholder="Search partners..." 
            data-testid="input-search-partners"
            className="pl-9 bg-background/50 border-white/10 focus-visible:ring-primary/50"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <div className="rounded-xl border border-white/5 bg-card/30 overflow-hidden shadow-xl">
        <Table>
          <TableHeader className="bg-white/5">
            <TableRow className="border-white/5 hover:bg-transparent">
              <TableHead className="text-muted-foreground font-medium">Partner Name</TableHead>
              <TableHead className="text-muted-foreground font-medium">Status</TableHead>
              <TableHead className="text-muted-foreground font-medium">Region</TableHead>
              <TableHead className="text-muted-foreground font-medium">Platform</TableHead>
              <TableHead className="text-muted-foreground font-medium">Phase</TableHead>
              <TableHead className="text-muted-foreground font-medium">Tier</TableHead>
              <TableHead className="text-muted-foreground font-medium text-right">Viewers</TableHead>
              <TableHead className="w-[50px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredPartners.map((partner) => (
              <TableRow key={partner.id} className="border-white/5 hover:bg-white/5 transition-colors group" data-testid={`row-partner-${partner.id}`}>
                <TableCell className="font-medium text-white">
                  <div className="flex flex-col">
                    <span className="text-base" data-testid={`text-partner-name-${partner.id}`}>{partner.name}</span>
                    <span className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                      <Mail className="w-3 h-3" /> {partner.email}
                    </span>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="secondary" className={`border-0 font-normal ${getStatusColor(partner.status)}`}>
                    {partner.status}
                  </Badge>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <MapPin className="w-3 h-3" />
                    {partner.region}
                  </div>
                </TableCell>
                <TableCell className="text-sm text-muted-foreground">{partner.platform}</TableCell>
                <TableCell className="text-sm text-muted-foreground">{partner.phase}</TableCell>
                <TableCell>
                  <div className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full border text-xs font-medium ${getTierColor(partner.tier)}`}>
                    <ShieldCheck className="w-3 h-3" />
                    {partner.tier}
                  </div>
                </TableCell>
                <TableCell className="text-right text-white font-mono">
                  {partner.activeViewers.toLocaleString()}
                </TableCell>
                <TableCell>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="h-8 w-8 p-0 text-muted-foreground hover:text-white" data-testid={`button-menu-${partner.id}`}>
                        <MoreVertical className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="bg-card border-white/10 text-white">
                      <DropdownMenuItem className="focus:bg-white/10 cursor-pointer">View Details</DropdownMenuItem>
                      <DropdownMenuItem className="focus:bg-white/10 cursor-pointer">Edit Settings</DropdownMenuItem>
                      <DropdownMenuItem 
                        className="text-destructive focus:bg-destructive/10 focus:text-destructive cursor-pointer"
                        onClick={() => deleteMutation.mutate(partner.id)}
                        data-testid={`button-delete-${partner.id}`}
                      >
                        Delete Partner
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        {filteredPartners.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            No partners found. Add your first partner to get started.
          </div>
        )}
      </div>
    </div>
  );
}
