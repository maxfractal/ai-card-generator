import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Type, 
  Palette, 
  Layout, 
  MousePointer2, 
  CheckCircle, 
  AlertCircle, 
  Info, 
  Activity 
} from "lucide-react";

export default function StyleGuide() {
  const colors = [
    { name: "Background", value: "hsl(220 30% 8%)", variable: "--background", class: "bg-background" },
    { name: "Card", value: "hsl(220 25% 12%)", variable: "--card", class: "bg-card" },
    { name: "Primary (Gold)", value: "hsl(45 90% 50%)", variable: "--primary", class: "bg-primary" },
    { name: "Secondary", value: "hsl(215 25% 20%)", variable: "--secondary", class: "bg-secondary" },
    { name: "Destructive", value: "hsl(0 80% 60%)", variable: "--destructive", class: "bg-destructive" },
    { name: "Muted", value: "hsl(215 25% 20%)", variable: "--muted", class: "bg-muted" },
    { name: "Accent", value: "hsl(215 25% 25%)", variable: "--accent", class: "bg-accent" },
  ];

  const chartColors = [
    { name: "Chart 1 (Gold)", class: "bg-[hsl(45_90%_50%)]" },
    { name: "Chart 2 (Cyan)", class: "bg-[hsl(200_90%_60%)]" },
    { name: "Chart 3 (Green)", class: "bg-[hsl(150_70%_50%)]" },
    { name: "Chart 4 (Red)", class: "bg-[hsl(340_80%_60%)]" },
    { name: "Chart 5 (Purple)", class: "bg-[hsl(270_60%_70%)]" },
  ];

  return (
    <div className="space-y-12 max-w-5xl mx-auto pb-12">
      <div className="space-y-2">
        <h1 className="text-4xl font-display font-bold text-white">Design System</h1>
        <p className="text-muted-foreground text-lg">
          A collection of design tokens, components, and patterns used in the Olympic Hub CRM.
        </p>
      </div>

      <Tabs defaultValue="colors" className="space-y-8">
        <TabsList className="bg-card/50 border border-white/5 p-1 h-auto">
          <TabsTrigger value="colors" className="px-4 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            <Palette className="w-4 h-4 mr-2" /> Colors
          </TabsTrigger>
          <TabsTrigger value="typography" className="px-4 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            <Type className="w-4 h-4 mr-2" /> Typography
          </TabsTrigger>
          <TabsTrigger value="components" className="px-4 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            <Layout className="w-4 h-4 mr-2" /> Components
          </TabsTrigger>
          <TabsTrigger value="effects" className="px-4 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            <MousePointer2 className="w-4 h-4 mr-2" /> Effects
          </TabsTrigger>
        </TabsList>

        <TabsContent value="colors" className="space-y-8">
          <section>
            <h2 className="text-2xl font-display font-semibold mb-6">Core Palette</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {colors.map((color) => (
                <div key={color.name} className="space-y-3">
                  <div className={`h-24 rounded-lg border border-white/10 shadow-lg ${color.class}`} />
                  <div>
                    <p className="font-medium text-white">{color.name}</p>
                    <p className="text-xs text-muted-foreground font-mono">{color.variable}</p>
                    <p className="text-xs text-muted-foreground font-mono mt-1">{color.value}</p>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-display font-semibold mb-6">Data Visualization</h2>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              {chartColors.map((color) => (
                <div key={color.name} className="space-y-3">
                  <div className={`h-16 rounded-lg border border-white/10 shadow-lg ${color.class}`} />
                  <p className="font-medium text-sm text-white">{color.name}</p>
                </div>
              ))}
            </div>
          </section>
        </TabsContent>

        <TabsContent value="typography" className="space-y-12">
          <section className="space-y-8">
            <div className="space-y-4">
              <span className="text-xs font-mono text-primary uppercase tracking-wider">Display Font - Space Grotesk</span>
              <div className="space-y-2">
                <h1 className="text-5xl font-display font-bold">Heading 1 - The Quick Brown Fox</h1>
                <h2 className="text-4xl font-display font-bold">Heading 2 - Jumps Over The Lazy Dog</h2>
                <h3 className="text-3xl font-display font-bold">Heading 3 - Olympic Hub CRM</h3>
                <h4 className="text-2xl font-display font-bold">Heading 4 - Partner Dashboard</h4>
              </div>
            </div>

            <Separator className="bg-white/10" />

            <div className="space-y-4">
              <span className="text-xs font-mono text-primary uppercase tracking-wider">Body Font - Inter</span>
              <div className="space-y-4 max-w-2xl">
                <p className="text-xl">
                  Lead - Use for introductions. Managing global streaming partners requires precision and real-time data analysis.
                </p>
                <p className="text-base text-muted-foreground">
                  Body - The default text style. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                </p>
                <p className="text-sm text-muted-foreground">
                  Small - Use for metadata or secondary information. Last updated 2 mins ago.
                </p>
                <p className="text-xs text-muted-foreground uppercase tracking-wider">
                  Caption - Use for labels or tags.
                </p>
              </div>
            </div>
          </section>
        </TabsContent>

        <TabsContent value="components" className="space-y-12">
          <section className="space-y-6">
            <h2 className="text-2xl font-display font-semibold">Buttons</h2>
            <div className="flex flex-wrap gap-4 items-center">
              <Button>Primary Button</Button>
              <Button variant="secondary">Secondary Button</Button>
              <Button variant="outline">Outline Button</Button>
              <Button variant="ghost">Ghost Button</Button>
              <Button variant="destructive">Destructive</Button>
              <Button size="sm">Small</Button>
              <Button size="lg">Large Button</Button>
            </div>
          </section>

          <section className="space-y-6">
            <h2 className="text-2xl font-display font-semibold">Badges & Status</h2>
            <div className="flex flex-wrap gap-4">
              <Badge>Default Badge</Badge>
              <Badge variant="secondary">Secondary</Badge>
              <Badge variant="outline">Outline</Badge>
              <Badge variant="destructive">Destructive</Badge>
              <Badge className="bg-primary text-primary-foreground hover:bg-primary/90">Custom Gold</Badge>
            </div>
          </section>

          <section className="space-y-6">
            <h2 className="text-2xl font-display font-semibold">Cards</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-card/50 border-white/5 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle>Glassmorphism Card</CardTitle>
                  <CardDescription>Standard card style for the dashboard</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    This card uses a semi-transparent background with a subtle border to create depth against the dark background.
                  </p>
                </CardContent>
              </Card>
              
              <Card className="bg-card border-white/10 hover:border-primary/50 transition-colors cursor-pointer group">
                <CardHeader>
                  <CardTitle className="group-hover:text-primary transition-colors">Interactive Card</CardTitle>
                  <CardDescription>Hover state example</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Hover over this card to see the border and title color transition.
                  </p>
                </CardContent>
              </Card>
            </div>
          </section>

          <section className="space-y-6">
            <h2 className="text-2xl font-display font-semibold">Form Elements</h2>
            <div className="max-w-md space-y-4 p-6 rounded-lg border border-white/5 bg-card/30">
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input id="email" placeholder="Enter your email" className="bg-secondary/50 border-white/10" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="search">Search</Label>
                <div className="relative">
                  <Input id="search" placeholder="Search..." className="pl-9 bg-secondary/50 border-white/10" />
                  <div className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-search"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </TabsContent>

        <TabsContent value="effects" className="space-y-12">
          <section className="space-y-6">
            <h2 className="text-2xl font-display font-semibold">Glassmorphism & Depth</h2>
            <div className="relative p-12 rounded-xl overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-900/40 via-background to-purple-900/40" />
              
              <div className="relative grid md:grid-cols-3 gap-8">
                <div className="glass-panel p-6 rounded-lg text-center space-y-2">
                  <p className="font-semibold text-white">Glass Panel</p>
                  <p className="text-xs text-muted-foreground">.glass-panel</p>
                </div>
                
                <div className="glass-card p-6 rounded-lg text-center space-y-2">
                  <p className="font-semibold text-white">Glass Card</p>
                  <p className="text-xs text-muted-foreground">.glass-card</p>
                </div>

                <div className="bg-background/80 backdrop-blur-md border border-white/10 p-6 rounded-lg text-center space-y-2">
                  <p className="font-semibold text-white">Header Blur</p>
                  <p className="text-xs text-muted-foreground">backdrop-blur-md</p>
                </div>
              </div>
            </div>
          </section>

          <section className="space-y-6">
            <h2 className="text-2xl font-display font-semibold">Glow Effects</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              <div className="h-24 rounded-lg bg-card border border-primary/50 shadow-[0_0_15px_rgba(234,179,8,0.3)] flex items-center justify-center">
                <span className="text-primary font-medium">Gold Glow</span>
              </div>
              <div className="h-24 rounded-lg bg-card border border-green-500/50 shadow-[0_0_15px_rgba(34,197,94,0.3)] flex items-center justify-center">
                <span className="text-green-500 font-medium">Success Glow</span>
              </div>
              <div className="h-24 rounded-lg bg-card border border-red-500/50 shadow-[0_0_15px_rgba(239,68,68,0.3)] flex items-center justify-center">
                <span className="text-red-500 font-medium">Error Glow</span>
              </div>
              <div className="h-24 rounded-lg bg-card border border-blue-500/50 shadow-[0_0_15px_rgba(59,130,246,0.3)] flex items-center justify-center">
                <span className="text-blue-500 font-medium">Info Glow</span>
              </div>
            </div>
          </section>
        </TabsContent>
      </Tabs>
    </div>
  );
}
