import { nanoid } from "nanoid";

export interface GameIdea {
  id: string;
  concept: string;
  targetAudience: string;
  problem: string;
  timestamp: number;
  result?: HeatIndexResult;
}

export interface HeatIndexResult {
  score: number; // 1-5
  label: string;
  fireCount: number;
  summary: string;
  competitors: string[];
  differentiation: string[];
  risks: string[];
  nextSteps: string[];
  drivers: string[];
}

export const STORAGE_KEY = "gamelaunch_ideas";

export function getSavedIdeas(): GameIdea[] {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch (e) {
    return [];
  }
}

export function saveIdea(idea: GameIdea) {
  const ideas = getSavedIdeas();
  const newIdeas = [idea, ...ideas];
  localStorage.setItem(STORAGE_KEY, JSON.stringify(newIdeas));
}

export function getIdeaById(id: string): GameIdea | undefined {
  const ideas = getSavedIdeas();
  return ideas.find((i) => i.id === id);
}

// Mock AI Analysis Logic
export async function analyzeIdea(
  concept: string,
  targetAudience: string,
  problem: string
): Promise<HeatIndexResult> {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 2500));

  // Pseudo-random generation based on input length to make it consistent for the same input
  const inputHash = (concept.length + targetAudience.length + problem.length) % 100;
  
  let score = 1;
  if (inputHash > 80) score = 5;
  else if (inputHash > 60) score = 4;
  else if (inputHash > 40) score = 3;
  else if (inputHash > 20) score = 2;
  
  // Ensure meaningful results for demo
  if (concept.toLowerCase().includes("mmo") || concept.toLowerCase().includes("rpg")) {
    score = Math.min(score, 3); // Harder to build
  }

  const resultTemplates: Record<number, HeatIndexResult> = {
    1: {
      score: 1,
      fireCount: 1,
      label: "Nice-to-have",
      summary: "This concept shows mild interest but lacks a clear hook or urgent player need. It feels like a 'vitamin' rather than a 'painkiller'.",
      competitors: ["Existing casual mobile games", "Generic platformers"],
      differentiation: ["Art style could be unique", "Specific niche setting"],
      risks: ["Low retention potential", "High cost of user acquisition", "Market saturation"],
      nextSteps: ["Refine the core loop", "Interview 10 players in this genre", "Pivot to a more specific problem"],
      drivers: ["Low differentiation", "Unclear audience"]
    },
    2: {
      score: 2,
      fireCount: 2,
      label: "Worth exploring",
      summary: "There is some pull here, but the positioning needs to be sharper. The audience is defined but the value proposition is weak.",
      competitors: ["Indie darlings in similar genre", "AA titles with overlapping themes"],
      differentiation: ["Novel mechanic combination", "Underserved sub-genre"],
      risks: ["Execution complexity", "Niche might be too small"],
      nextSteps: ["Create a 1-page GDD", "Test key mechanic with prototype", "A/B test the hook"],
      drivers: ["Moderate audience reach", "Standard mechanics"]
    },
    3: {
      score: 3,
      fireCount: 3,
      label: "Real opportunity",
      summary: "Clear audience and manageable competition. This is a solid contender that solves a known desire for players.",
      competitors: ["Dated classics in the genre", "Games with poor UX"],
      differentiation: ["Modern quality of life improvements", "Fresh narrative angle"],
      risks: ["Scope creep", "Marketing visibility"],
      nextSteps: ["Build a vertical slice", "Start building a community", "Create a Steam page"],
      drivers: ["Clear problem/solution fit", "Feasible scope"]
    },
    4: {
      score: 4,
      fireCount: 4,
      label: "Hot market",
      summary: "Strong demand signals with a differentiated angle. Players are actively looking for this kind of experience.",
      competitors: ["Fragmented market leaders", "Games that ignore this specific niche"],
      differentiation: ["Strong community hook", "Viral mechanic potential"],
      risks: ["Copycats", "Technical scaling"],
      nextSteps: ["Launch a pre-order campaign", "Partner with influencers", "Polish the core loop"],
      drivers: ["High differentiation", "Strong market pull"]
    },
    5: {
      score: 5,
      fireCount: 5,
      label: "Hair on fire",
      summary: "Urgent need in an underserved niche. This concept has 'lightning in a bottle' potential if executed well.",
      competitors: ["None direct (Blue Ocean)", "Hack solutions players use now"],
      differentiation: ["First mover advantage", "Radically new experience"],
      risks: ["Execution speed (race to market)", "Platform stability"],
      nextSteps: ["Immediate prototype", "Seek funding/publisher", "Go all-in on marketing"],
      drivers: ["Extreme urgency", "Massive reach potential"]
    }
  };

  return resultTemplates[score];
}
