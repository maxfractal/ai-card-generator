import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useState } from "react";
import { useLocation } from "wouter";
import { analyzeIdea, saveIdea, GameIdea } from "@/lib/store";
import { nanoid } from "nanoid";
import { motion, AnimatePresence } from "framer-motion";
import { Loader2, Flame, Sparkles } from "lucide-react";

const formSchema = z.object({
  concept: z.string().min(10, "Describe your game loop in at least 10 characters"),
  targetAudience: z.string().min(5, "Who is this for?"),
  problem: z.string().min(10, "What problem does this solve?"),
});

export default function Validate() {
  const [isLoading, setIsLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState(0);
  const [, setLocation] = useLocation();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      concept: "",
      targetAudience: "",
      problem: "",
    },
  });

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true);
    
    // Animate loading steps
    const steps = ["Analyzing market pull...", "Finding competitive comps...", "Calculating heat index..."];
    let step = 0;
    const interval = setInterval(() => {
      step++;
      if (step < steps.length) setLoadingStep(step);
    }, 800);

    try {
      const result = await analyzeIdea(values.concept, values.targetAudience, values.problem);
      
      const idea: GameIdea = {
        id: nanoid(),
        ...values,
        timestamp: Date.now(),
        result
      };
      
      saveIdea(idea);
      clearInterval(interval);
      
      // Artificial delay to show the last step
      setTimeout(() => {
        setLocation(`/validations/${idea.id}`);
      }, 500);
    } catch (error) {
      console.error(error);
      setIsLoading(false);
      clearInterval(interval);
    }
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 max-w-3xl pt-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-10 text-center"
        >
          <h1 className="text-4xl md:text-5xl font-bold font-display mb-4">Validate your idea</h1>
          <p className="text-muted-foreground text-lg">Tell us about your game concept. We'll handle the rest.</p>
        </motion.div>

        <div className="glass-card p-8 md:p-10 rounded-3xl border border-white/10 relative overflow-hidden">
          {isLoading && (
            <div className="absolute inset-0 z-50 bg-background/80 backdrop-blur-xl flex flex-col items-center justify-center">
              <motion.div 
                animate={{ rotate: 360 }}
                transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
                className="mb-6"
              >
                <div className="relative">
                  <div className="absolute inset-0 bg-primary blur-xl opacity-50 rounded-full" />
                  <Loader2 className="w-16 h-16 text-primary relative z-10" />
                </div>
              </motion.div>
              <h3 className="text-2xl font-display font-bold animate-pulse">
                {["Analyzing market pull...", "Finding competitive comps...", "Calculating heat index..."][loadingStep]}
              </h3>
            </div>
          )}

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
              <FormField
                control={form.control}
                name="concept"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-lg font-display">Game Concept</FormLabel>
                    <div className="text-sm text-muted-foreground mb-2">Describe the core loop and the "hook". What do players actually do?</div>
                    <FormControl>
                      <Textarea 
                        placeholder="e.g. A rogue-like deckbuilder where you play as a sentient vending machine..." 
                        className="bg-black/20 border-white/10 min-h-[120px] text-lg focus:border-primary/50 transition-colors resize-none"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid md:grid-cols-2 gap-8">
                <FormField
                  control={form.control}
                  name="targetAudience"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-lg font-display">Target Players</FormLabel>
                      <div className="text-sm text-muted-foreground mb-2">Who is this for? Platform?</div>
                      <FormControl>
                        <Input 
                          placeholder="e.g. Steam Deck users, Cozy gamers..." 
                          className="bg-black/20 border-white/10 h-12 text-lg focus:border-primary/50 transition-colors"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="problem"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-lg font-display">Player Problem</FormLabel>
                      <div className="text-sm text-muted-foreground mb-2">What pain or desire does this solve?</div>
                      <FormControl>
                        <Input 
                          placeholder="e.g. Need for short sessions, nostalgia..." 
                          className="bg-black/20 border-white/10 h-12 text-lg focus:border-primary/50 transition-colors"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="pt-4 flex justify-end">
                <Button 
                  type="submit" 
                  size="lg" 
                  className="w-full md:w-auto h-14 px-8 text-lg rounded-full bg-gradient-primary hover:opacity-90 shadow-[0_0_20px_-5px_rgba(234,88,12,0.5)] transition-all hover:scale-105"
                  disabled={isLoading}
                >
                  {isLoading ? "Processing..." : (
                    <>
                      Get my heat index <Sparkles className="ml-2 w-5 h-5" />
                    </>
                  )}
                </Button>
              </div>
            </form>
          </Form>
        </div>
      </div>
    </Layout>
  );
}
