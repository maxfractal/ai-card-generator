import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { getSavedIdeas, GameIdea } from "@/lib/store";
import { Flame, Calendar, ArrowRight, Plus } from "lucide-react";
import { format } from "date-fns";

export default function Ideas() {
  const ideas = getSavedIdeas();

  return (
    <Layout>
      <div className="container mx-auto px-4 pt-10 pb-20 max-w-5xl">
        <div className="flex items-center justify-between mb-10">
          <h1 className="text-4xl font-display font-bold">Saved Ideas</h1>
          <Link href="/validate">
            <Button className="bg-white/10 hover:bg-white/20 text-white border-0">
              <Plus className="w-4 h-4 mr-2" /> New Validation
            </Button>
          </Link>
        </div>

        {ideas.length === 0 ? (
          <div className="glass-card p-16 rounded-3xl border border-white/10 text-center flex flex-col items-center">
            <div className="w-20 h-20 rounded-full bg-white/5 flex items-center justify-center mb-6">
              <Flame className="w-10 h-10 text-muted-foreground" />
            </div>
            <h3 className="text-2xl font-bold font-display mb-2">No ideas saved yet</h3>
            <p className="text-muted-foreground max-w-md mx-auto mb-8">
              Validate your first game concept to see your heat index results here.
            </p>
            <Link href="/validate">
              <Button size="lg" className="bg-gradient-primary text-white">
                Validate an Idea
              </Button>
            </Link>
          </div>
        ) : (
          <div className="grid gap-4">
            {ideas.map((idea) => (
              <Link key={idea.id} href={`/validations/${idea.id}`}>
                <div className="glass-card p-6 rounded-2xl border border-white/5 hover:border-primary/50 hover:bg-white/5 transition-all cursor-pointer group">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <div className={`px-2 py-0.5 rounded text-xs font-bold uppercase tracking-wider ${
                          (idea.result?.score || 0) >= 4 ? "bg-primary/20 text-primary" : "bg-white/10 text-muted-foreground"
                        }`}>
                          Heat Index: {idea.result?.score}/5
                        </div>
                        <div className="flex items-center text-xs text-muted-foreground">
                          <Calendar className="w-3 h-3 mr-1" />
                          {format(idea.timestamp, "MMM d, yyyy")}
                        </div>
                      </div>
                      <h3 className="text-xl font-bold font-display group-hover:text-primary transition-colors mb-1">
                        {idea.concept.length > 80 ? idea.concept.slice(0, 80) + "..." : idea.concept}
                      </h3>
                      <p className="text-sm text-muted-foreground line-clamp-1">
                        Target: {idea.targetAudience}
                      </p>
                    </div>
                    
                    <div className="flex items-center gap-4">
                      <div className="flex gap-0.5">
                         {Array.from({ length: 5 }).map((_, i) => (
                            <Flame 
                              key={i} 
                              className={`w-4 h-4 ${(i < (idea.result?.score || 0)) ? "text-primary fill-primary" : "text-white/10"}`} 
                            />
                          ))}
                      </div>
                      <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:translate-x-1 transition-transform" />
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
}
