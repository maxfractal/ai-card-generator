import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Check, Clipboard, Terminal, Server, Gamepad, Monitor, CheckCircle } from "lucide-react";
import { useState } from "react";

export default function Docs() {
  return (
    <Layout>
      <div className="container mx-auto px-4 pt-10 pb-20">
        <div className="grid lg:grid-cols-[250px_1fr] gap-10 max-w-6xl mx-auto">
          
          {/* Sidebar Nav */}
          <aside className="hidden lg:block space-y-8 sticky top-24 h-fit">
            <div>
              <h4 className="font-display font-bold text-lg mb-4 text-white">Getting Started</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#intro" className="hover:text-primary transition-colors">Introduction</a></li>
                <li><a href="#quickstart" className="hover:text-primary transition-colors">Quick Start</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-display font-bold text-lg mb-4 text-white">Guidelines</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#input" className="hover:text-primary transition-colors">Input & Controls</a></li>
                <li><a href="#performance" className="hover:text-primary transition-colors">Performance</a></li>
                <li><a href="#tv" className="hover:text-primary transition-colors">TV Compatibility</a></li>
              </ul>
            </div>
          </aside>

          {/* Main Content */}
          <div className="space-y-12">
            <section id="intro">
              <h1 className="text-5xl font-display font-bold mb-6">Developer Standards</h1>
              <p className="text-xl text-muted-foreground leading-relaxed mb-8">
                The official handbook for building, testing, and shipping games that pass the Heat Index validation. 
                Focus on performance, controller support, and TV-first experiences.
              </p>
              
              <div className="p-6 rounded-xl bg-primary/10 border border-primary/20">
                <h4 className="font-bold text-primary mb-2 flex items-center gap-2">
                  <Terminal className="w-5 h-5" /> Why this matters
                </h4>
                <p className="text-sm text-primary/80">
                  Games that follow these standards have a 3x higher likelihood of reaching a Heat Index of 4 or 5. 
                  Platform quality is a key feasibility metric.
                </p>
              </div>
            </section>

            <section id="quickstart" className="space-y-6">
              <h2 className="text-3xl font-display font-bold border-b border-white/10 pb-4">Quick Start</h2>
              <p className="text-muted-foreground">Install the CLI tool to run local validation checks against your build.</p>
              
              <CodeBlock code="npm install -g @gamelaunch/cli" />
              <CodeBlock code="gamelaunch init" />
            </section>

            <section id="input" className="space-y-6">
              <h2 className="text-3xl font-display font-bold border-b border-white/10 pb-4">Input & Controls</h2>
              <p className="text-muted-foreground">
                Your game must fully support gamepad navigation. Mouse/Keyboard should be secondary for TV-focused titles.
              </p>
              
              <div className="grid md:grid-cols-2 gap-6">
                 <div className="glass-card p-6 rounded-xl border border-white/5">
                    <h3 className="font-bold mb-4 flex items-center gap-2">
                       <Gamepad className="w-5 h-5 text-green-400" /> Mandatory
                    </h3>
                    <ul className="space-y-3">
                       <CheckItem text="Full menu navigation via D-pad" />
                       <CheckItem text="A/B (Cross/Circle) confirm/back standard" />
                       <CheckItem text="Disconnect handling (pause game)" />
                    </ul>
                 </div>
                 <div className="glass-card p-6 rounded-xl border border-white/5">
                    <h3 className="font-bold mb-4 flex items-center gap-2">
                       <Monitor className="w-5 h-5 text-blue-400" /> TV Safe Zones
                    </h3>
                    <ul className="space-y-3">
                       <CheckItem text="Keep UI within 90% safe area" />
                       <CheckItem text="Min font size: 24px (1080p ref)" />
                       <CheckItem text="High contrast focus states" />
                    </ul>
                 </div>
              </div>
            </section>
            
            <section id="performance" className="space-y-6">
               <h2 className="text-3xl font-display font-bold border-b border-white/10 pb-4">Performance & Reliability</h2>
               <div className="overflow-x-auto">
                 <table className="w-full text-left text-sm">
                   <thead>
                     <tr className="border-b border-white/10">
                       <th className="py-4 px-4 font-bold text-white">Metric</th>
                       <th className="py-4 px-4 font-bold text-white">Target</th>
                       <th className="py-4 px-4 font-bold text-white">Fail Threshold</th>
                     </tr>
                   </thead>
                   <tbody className="divide-y divide-white/5 text-muted-foreground">
                     <tr>
                       <td className="py-4 px-4">Frame Rate</td>
                       <td className="py-4 px-4 text-green-400">60 FPS (Stable)</td>
                       <td className="py-4 px-4 text-red-400">&lt; 30 FPS</td>
                     </tr>
                     <tr>
                       <td className="py-4 px-4">Load Time</td>
                       <td className="py-4 px-4 text-green-400">&lt; 5 Seconds</td>
                       <td className="py-4 px-4 text-red-400">&gt; 15 Seconds</td>
                     </tr>
                     <tr>
                       <td className="py-4 px-4">Input Latency</td>
                       <td className="py-4 px-4 text-green-400">&lt; 50ms</td>
                       <td className="py-4 px-4 text-red-400">&gt; 100ms</td>
                     </tr>
                   </tbody>
                 </table>
               </div>
            </section>

          </div>
        </div>
      </div>
    </Layout>
  );
}

function CodeBlock({ code }: { code: string }) {
  const [copied, setCopied] = useState(false);

  const copy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="relative group rounded-lg overflow-hidden bg-black/40 border border-white/10">
      <div className="absolute right-2 top-2 opacity-0 group-hover:opacity-100 transition-opacity">
        <Button size="icon" variant="ghost" className="h-8 w-8 text-muted-foreground hover:text-white" onClick={copy}>
          {copied ? <Check className="w-4 h-4" /> : <Clipboard className="w-4 h-4" />}
        </Button>
      </div>
      <pre className="p-4 font-mono text-sm overflow-x-auto text-blue-300">
        <code>{code}</code>
      </pre>
    </div>
  );
}

function CheckItem({ text }: { text: string }) {
  return (
    <li className="flex items-start gap-3 text-sm text-muted-foreground">
      <CheckCircle className="w-4 h-4 text-primary mt-0.5 shrink-0" />
      <span>{text}</span>
    </li>
  );
}
