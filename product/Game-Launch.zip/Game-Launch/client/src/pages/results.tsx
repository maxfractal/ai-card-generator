import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Link, useRoute } from "wouter";
import { getIdeaById } from "@/lib/store";
import { motion } from "framer-motion";
import { Flame, ArrowRight, Share2, Copy, AlertTriangle, CheckCircle, Trophy, Target } from "lucide-react";
import NotFound from "@/pages/not-found";

export default function Results() {
  const [, params] = useRoute("/validations/:id");
  const idea = getIdeaById(params?.id || "");

  if (!idea || !idea.result) {
    return <NotFound />;
  }

  const { result } = idea;

  return (
    <Layout>
      <div className="container mx-auto px-4 pt-10 pb-20">
        <div className="max-w-5xl mx-auto">
          <div className="flex flex-col md:flex-row gap-6 md:items-center justify-between mb-10">
            <div>
              <div className="text-sm text-muted-foreground mb-1 uppercase tracking-widest font-bold">Validation Result</div>
              <h1 className="text-3xl md:text-4xl font-display font-bold text-white max-w-2xl leading-tight">{idea.concept.slice(0, 60)}{idea.concept.length > 60 && "..."}</h1>
            </div>
            <div className="flex gap-3">
              <Link href="/validate">
                <Button variant="outline" className="border-white/10 hover:bg-white/5">Validate another</Button>
              </Link>
              <Button className="bg-white/10 hover:bg-white/20 text-white border-0"><Share2 className="w-4 h-4 mr-2"/> Share</Button>
            </div>
          </div>

          <div className="grid md:grid-cols-12 gap-8">
            {/* Left Column - Score */}
            <div className="md:col-span-5 lg:col-span-4 space-y-6">
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="glass-card p-8 rounded-3xl border-t border-white/10 bg-gradient-to-b from-white/5 to-black/40 text-center relative overflow-hidden"
              >
                {/* Glow behind score */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-40 h-40 bg-primary/20 blur-[80px] rounded-full" />
                
                <h3 className="text-lg font-medium text-muted-foreground mb-4 uppercase tracking-widest">Heat Index</h3>
                
                <div className="flex items-center justify-center gap-2 mb-6">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.1 }}
                    >
                      <Flame 
                        className={`w-10 h-10 ${i < result.score ? "text-primary fill-primary drop-shadow-[0_0_10px_rgba(234,88,12,0.8)]" : "text-white/10"}`} 
                      />
                    </motion.div>
                  ))}
                </div>
                
                <div className="text-6xl font-bold font-display mb-2 text-white">{result.score}/5</div>
                <div className="text-xl font-medium text-primary mb-6">{result.label}</div>
                
                <div className="h-2 w-full bg-white/10 rounded-full overflow-hidden mb-6">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${(result.score / 5) * 100}%` }}
                    transition={{ duration: 1, ease: "easeOut" }}
                    className="h-full bg-gradient-primary"
                  />
                </div>
                
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {result.summary}
                </p>
              </motion.div>

              <div className="glass-card p-6 rounded-2xl border border-white/5">
                <h4 className="font-display font-bold mb-4 flex items-center gap-2">
                  <Target className="w-5 h-5 text-primary" /> Key Drivers
                </h4>
                <ul className="space-y-3">
                  {result.drivers.map((driver, i) => (
                    <li key={i} className="flex items-start gap-3 text-sm text-muted-foreground">
                      <div className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5" />
                      {driver}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Right Column - Analysis */}
            <div className="md:col-span-7 lg:col-span-8 space-y-8">
              
              {/* Risks & Comps */}
              <div className="grid md:grid-cols-2 gap-6">
                 <div className="glass-card p-6 rounded-2xl border border-white/5">
                  <h4 className="font-display font-bold mb-4 flex items-center gap-2 text-red-400">
                    <AlertTriangle className="w-5 h-5" /> Top Risks
                  </h4>
                  <ul className="space-y-3">
                    {result.risks.map((risk, i) => (
                      <li key={i} className="flex items-start gap-3 text-sm text-muted-foreground">
                        <div className="w-1.5 h-1.5 rounded-full bg-red-500/50 mt-1.5" />
                        {risk}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="glass-card p-6 rounded-2xl border border-white/5">
                  <h4 className="font-display font-bold mb-4 flex items-center gap-2 text-blue-400">
                    <Trophy className="w-5 h-5" /> Competitive Comps
                  </h4>
                  <ul className="space-y-3">
                    {result.competitors.map((comp, i) => (
                      <li key={i} className="flex items-start gap-3 text-sm text-muted-foreground">
                        <div className="w-1.5 h-1.5 rounded-full bg-blue-500/50 mt-1.5" />
                        {comp}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Differentiation */}
              <div className="glass-card p-8 rounded-2xl border border-white/5 bg-gradient-to-r from-primary/5 to-transparent">
                 <h4 className="text-xl font-display font-bold mb-4">Differentiation Opportunities</h4>
                 <div className="grid gap-4">
                    {result.differentiation.map((diff, i) => (
                      <div key={i} className="flex items-start gap-4 p-4 rounded-xl bg-white/5 border border-white/5">
                         <div className="p-2 rounded-lg bg-primary/20 text-primary">
                           <SparklesIcon className="w-4 h-4" />
                         </div>
                         <div>
                           <p className="text-white font-medium">{diff}</p>
                         </div>
                      </div>
                    ))}
                 </div>
              </div>

              {/* Next Steps */}
              <div className="space-y-4">
                <h3 className="text-2xl font-display font-bold">Recommended Next Steps</h3>
                <div className="grid gap-4">
                  {result.nextSteps.map((step, i) => (
                    <div key={i} className="flex items-center gap-4 p-5 rounded-xl border border-white/10 bg-card hover:border-primary/50 transition-colors group cursor-pointer">
                      <div className="h-8 w-8 rounded-full border border-white/20 flex items-center justify-center text-sm font-bold text-muted-foreground group-hover:bg-primary group-hover:border-primary group-hover:text-white transition-all">
                        {i + 1}
                      </div>
                      <span className="text-lg text-foreground/80 group-hover:text-white transition-colors">{step}</span>
                      <ArrowRight className="ml-auto w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors opacity-0 group-hover:opacity-100" />
                    </div>
                  ))}
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}

function SparklesIcon({ className }: { className?: string }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z" />
    </svg>
  )
}
