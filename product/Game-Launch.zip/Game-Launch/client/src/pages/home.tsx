import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { ArrowRight, Brain, Gamepad2, Flame, BarChart3, CheckCircle2 } from "lucide-react";
import heroBg from "@assets/generated_images/abstract_warm_gradient_background_for_game_validation_platform.png";

export default function Home() {
  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative min-h-[80vh] flex flex-col items-center justify-center text-center px-4 pt-20 pb-32 overflow-hidden">
        {/* Abstract Background Image with overlay */}
        <div className="absolute inset-0 z-[-1]">
          <img 
            src={heroBg} 
            alt="Background" 
            className="w-full h-full object-cover opacity-40 mix-blend-screen"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background via-background/80 to-background" />
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto space-y-8"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 backdrop-blur-sm mb-4">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
            </span>
            <span className="text-sm font-medium text-muted-foreground uppercase tracking-wider">AI-Powered Validation</span>
          </div>

          <h1 className="text-6xl md:text-8xl font-bold font-display tracking-tighter leading-[0.9]">
            How hot is your <br />
            <span className="text-gradient-primary">game idea?</span>
          </h1>
          
          <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            AI-powered validation in 60 seconds. <br className="hidden md:block"/>
            Assess demand, competition, and market pull instantly.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-8">
            <Link href="/validate">
              <Button size="lg" className="h-14 px-8 text-lg rounded-full bg-gradient-primary hover:opacity-90 shadow-[0_0_40px_-10px_rgba(234,88,12,0.5)] transition-all hover:scale-105">
                Get your heat index <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
          </div>
        </motion.div>
      </section>

      {/* How it Works */}
      <section className="py-24 relative">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            <FeatureCard 
              icon={<Gamepad2 className="w-8 h-8 text-primary" />}
              title="Share your concept"
              description="Describe the core loop, target players, and what itch the game scratches."
              delay={0.1}
            />
            <FeatureCard 
              icon={<Brain className="w-8 h-8 text-primary" />}
              title="AI analyzes the market"
              description="We assess demand signals, competition, and differentiation against live market data."
              delay={0.2}
            />
            <FeatureCard 
              icon={<Flame className="w-8 h-8 text-primary" />}
              title="Get your heat index"
              description="Receive a Heat Index (1–5) with actionable insights and fast validation tests."
              delay={0.3}
            />
          </div>
        </div>
      </section>

      {/* Heat Index Explanation */}
      <section className="py-24 bg-white/2">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold font-display mb-4">Understanding the Heat Index</h2>
            <p className="text-muted-foreground text-lg">Our proprietary scoring model for game viability</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <HeatLevel level={1} title="Nice-to-have" desc="Mild interest, unclear hook" />
            <HeatLevel level={2} title="Worth exploring" desc="Some pull, needs positioning" />
            <HeatLevel level={3} title="Real opportunity" desc="Clear audience, manageable comps" />
            <HeatLevel level={4} title="Hot market" desc="Strong demand, differentiated" />
            <HeatLevel level={5} title="Hair on fire" desc="Urgent need, underserved niche" />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-32 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-t from-primary/10 to-transparent" />
        <div className="container mx-auto px-4 text-center relative z-10">
          <h2 className="text-5xl md:text-6xl font-bold font-display mb-6">Ready to test your idea?</h2>
          <p className="text-xl text-muted-foreground mb-10 max-w-2xl mx-auto">
            Get your heat index in 60 seconds — free, no signup required.
          </p>
          <Link href="/validate">
            <Button size="lg" variant="outline" className="h-14 px-10 text-lg rounded-full border-white/20 bg-white/5 hover:bg-white/10 hover:border-primary/50 transition-all backdrop-blur-md">
              Get started free <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Link>
        </div>
      </section>
    </Layout>
  );
}

function FeatureCard({ icon, title, description, delay }: { icon: React.ReactNode, title: string, description: string, delay: number }) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay, duration: 0.5 }}
      className="glass-card p-8 rounded-2xl border border-white/5 bg-gradient-to-b from-white/5 to-transparent hover:border-primary/30 transition-colors group"
    >
      <div className="mb-6 p-4 rounded-xl bg-white/5 w-fit group-hover:bg-primary/20 transition-colors">
        {icon}
      </div>
      <h3 className="text-2xl font-bold font-display mb-3">{title}</h3>
      <p className="text-muted-foreground leading-relaxed">{description}</p>
    </motion.div>
  );
}

function HeatLevel({ level, title, desc }: { level: number, title: string, desc: string }) {
  const isHigh = level >= 4;
  return (
    <div className={`p-6 rounded-xl border transition-all hover:-translate-y-1 ${
      isHigh ? "bg-primary/10 border-primary/30" : "bg-card border-white/5"
    }`}>
      <div className="flex gap-1 mb-3">
        {Array.from({ length: level }).map((_, i) => (
          <Flame key={i} className={`w-4 h-4 ${isHigh ? "text-primary fill-primary" : "text-primary/70"}`} />
        ))}
      </div>
      <div className="text-2xl font-bold font-display mb-1">{level}/5</div>
      <div className="font-bold text-sm mb-2">{title}</div>
      <p className="text-xs text-muted-foreground">{desc}</p>
    </div>
  );
}
