import { Link, useLocation } from "wouter";
import { Gamepad2, Menu, X, Flame } from "lucide-react";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { motion } from "framer-motion";

export function Navbar() {
  const [location] = useLocation();
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { href: "/validate", label: "Validate Idea" },
    { href: "/ideas", label: "Saved Ideas" },
    { href: "/docs", label: "Developer Docs" },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? "bg-background/80 backdrop-blur-md border-b border-white/5 py-4" : "bg-transparent py-6"
      }`}
    >
      <div className="container mx-auto px-4 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 group cursor-pointer">
            <div className="relative">
              <div className="absolute inset-0 bg-primary/20 blur-lg rounded-full group-hover:bg-primary/40 transition-all" />
              <Flame className="w-8 h-8 text-primary relative z-10 transition-transform group-hover:scale-110" />
            </div>
            <span className="text-xl font-bold font-display tracking-tight group-hover:text-primary transition-colors">
              GameLaunch
            </span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <Link key={link.href} href={link.href} className={`text-sm font-medium transition-colors hover:text-primary cursor-pointer ${
                  location === link.href ? "text-primary" : "text-muted-foreground"
                }`}>
                {link.label}
            </Link>
          ))}
          <Link href="/validate">
            <Button className="bg-gradient-primary hover:opacity-90 border-0 shadow-lg shadow-orange-500/20 text-white font-semibold">
              Get Heat Index
            </Button>
          </Link>
        </nav>

        {/* Mobile Nav */}
        <div className="md:hidden">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="w-6 h-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="bg-card/95 backdrop-blur-xl border-l border-white/10">
              <div className="flex flex-col gap-8 mt-10">
                {navLinks.map((link) => (
                  <Link key={link.href} href={link.href} className="text-xl font-medium font-display hover:text-primary transition-colors cursor-pointer">
                      {link.label}
                  </Link>
                ))}
                <Link href="/validate">
                  <Button className="w-full bg-gradient-primary text-white">Get Heat Index</Button>
                </Link>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}

export function Footer() {
  return (
    <footer className="bg-black/40 border-t border-white/5 py-12 mt-20">
      <div className="container mx-auto px-4 text-center text-muted-foreground text-sm">
        <div className="flex items-center justify-center gap-2 mb-4">
          <Flame className="w-5 h-5 text-primary/50" />
          <span className="font-display font-bold text-white/50">GameLaunch Heat Index</span>
        </div>
        <p className="mb-4">© 2025 maxfractal LLC. All rights reserved.</p>
        <div className="flex justify-center gap-6">
          <a href="#" className="hover:text-white transition-colors">Privacy</a>
          <a href="#" className="hover:text-white transition-colors">Terms</a>
        </div>
      </div>
    </footer>
  );
}

export function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground overflow-x-hidden">
      <div className="fixed inset-0 z-[-1] pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-primary/10 blur-[150px] rounded-full opacity-50" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[30%] h-[30%] bg-blue-500/10 blur-[150px] rounded-full opacity-30" />
      </div>
      <Navbar />
      <main className="flex-1 pt-24 pb-10">
        {children}
      </main>
      <Footer />
    </div>
  );
}
