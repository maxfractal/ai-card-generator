import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import Validate from "@/pages/validate";
import Results from "@/pages/results";
import Ideas from "@/pages/ideas";
import Docs from "@/pages/docs";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/validate" component={Validate} />
      <Route path="/validations/:id" component={Results} />
      <Route path="/ideas" component={Ideas} />
      <Route path="/docs" component={Docs} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
