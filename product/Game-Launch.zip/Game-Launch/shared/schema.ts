import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const gameIdeas = pgTable("game_ideas", {
  id: varchar("id").primaryKey(),
  concept: text("concept").notNull(),
  targetAudience: text("target_audience").notNull(),
  problem: text("problem").notNull(),
  heatScore: integer("heat_score").notNull(),
  label: text("label").notNull(),
  summary: text("summary").notNull(),
  competitors: text("competitors").array().notNull(),
  differentiation: text("differentiation").array().notNull(),
  risks: text("risks").array().notNull(),
  nextSteps: text("next_steps").array().notNull(),
  drivers: text("drivers").array().notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const insertGameIdeaSchema = createInsertSchema(gameIdeas).omit({
  timestamp: true,
});

export type InsertGameIdea = z.infer<typeof insertGameIdeaSchema>;
export type GameIdea = typeof gameIdeas.$inferSelect;
